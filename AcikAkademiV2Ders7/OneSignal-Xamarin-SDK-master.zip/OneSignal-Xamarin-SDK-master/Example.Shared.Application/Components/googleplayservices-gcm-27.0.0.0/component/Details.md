Google Play Services - GCM
==========================

Google Cloud Messaging (GCM) is a free service that enables developers to send messages between servers and client apps. This includes downstream messages from servers to client apps, and upstream messages from client apps to servers.

For example, a lightweight downstream message could inform a client app that there is new data to be fetched from the server, as in the case of a "new email" notification. For use cases such as instant messaging, a GCM message can transfer up to 4kb of payload to the client app. The GCM service handles all aspects of queueing of messages and delivery to and from the target client app.





Google Play Services
====================

Give your apps more features to attract users on a wider range of devices. With Google Play services, your app can take advantage of the latest, Google-powered features such as Maps, Google+, and more, with automatic platform updates distributed as an APK through the Google Play store. This makes it faster for your users to receive updates and easier for you to integrate the newest that Google has to offer.


Develop
-------

Ship higher quality apps. Faster.
Get a headstart on your development with Google services that you can use out-of-the-box.
 - Analytics
 - Sign in with Google
 - Maps
 - Places
 - Engage



Grow an active user base
------------------------

Reach new users and find ways to keep them coming back to your app.
 - Google Cloud Messaging
 - App Indexing
 - App Install Ads
 - App Invites
 - Earn



Tap into a range of tools to make more money
--------------------------------------------

Take a user-by-user approach to monetization that maximizes your app revenue.
 - AdMob
 - In-App Billing and Subscriptions
 - Android Pay
 


More ways to enhance your app
-----------------------------

### Use location to power context

Respond to where users are and what they're doing. Enrich your app with high-accuracy location reporting, geofencing, and activity recognition.

### Stream content to TVs and speakers
Let users send audio and visual content to any Cast-enabled TV or speaker and control it from their phones or tablets.

### Add social features to your games
Enhance your games and learn more about your players. Add achievements, leaderboards, saved games, real-time multiplayer, and more.

### Enhance your app for fitness
Participate in the fitness ecosystem and add high-engagement features to your app. Analyze raw sensor data or take advantage of shared fitness data.

### Store and manage files in the cloud
Let users interact with nearly any aspect of their Google Drive content, including sharing permissions, file revisions, and connected apps.

### Support voice actions
Let users engage with your app quickly and conveniently through voice commands. Respond to system actions or add custom actions of your own.

